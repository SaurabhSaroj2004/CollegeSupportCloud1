import Header from '@/components/Header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, XCircle, Users, Building, TrendingUp } from 'lucide-react';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';

export default function Admin() {
  const [user] = useState({ name: 'Sanny Kumar', email: 'sanny@college.edu', role: 'admin' });
  const [serviceType, setServiceType] = useState('hospital');
  const { toast } = useToast();

  const stats = [
    { icon: Building, label: 'Total Services', value: '604', color: 'text-primary' },
    { icon: Users, label: 'Active Users', value: '10,234', color: 'text-green-600' },
    { icon: TrendingUp, label: 'Pending Reviews', value: '12', color: 'text-orange-600' },
  ];

  const pendingServices = [
    {
      id: '1',
      name: 'New City Hospital',
      type: 'hospital',
      submittedBy: 'john@college.edu',
      date: '2 hours ago',
    },
    {
      id: '2',
      name: 'Quick Pharmacy',
      type: 'pharmacy',
      submittedBy: 'sarah@college.edu',
      date: '5 hours ago',
    },
    {
      id: '3',
      name: 'Express E-Rickshaw',
      type: 'erickshaw',
      submittedBy: 'mike@college.edu',
      date: '1 day ago',
    },
  ];

  const handleApprove = (id: string, name: string) => {
    console.log('Approved:', id);
    toast({
      title: 'Service approved',
      description: `${name} has been verified and published.`,
    });
  };

  const handleReject = (id: string, name: string) => {
    console.log('Rejected:', id);
    toast({
      title: 'Service rejected',
      description: `${name} has been rejected.`,
      variant: 'destructive',
    });
  };

  const handleAddService = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('New service added');
    toast({
      title: 'Service added',
      description: 'The new service has been created successfully.',
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header user={user} />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2" data-testid="text-admin-title">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage services and review submissions</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
                    <p className="text-3xl font-bold" data-testid={`stat-${stat.label.toLowerCase().replace(' ', '-')}`}>
                      {stat.value}
                    </p>
                  </div>
                  <stat.icon className={`h-12 w-12 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs defaultValue="pending" className="space-y-6">
          <TabsList>
            <TabsTrigger value="pending" data-testid="tab-pending">
              Pending Reviews ({pendingServices.length})
            </TabsTrigger>
            <TabsTrigger value="add" data-testid="tab-add">
              Add New Service
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Pending Service Verifications</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {pendingServices.map((service) => (
                    <div
                      key={service.id}
                      className="flex items-center justify-between p-4 border rounded-lg"
                      data-testid={`pending-service-${service.id}`}
                    >
                      <div className="flex-1">
                        <h4 className="font-semibold mb-1">{service.name}</h4>
                        <div className="flex items-center gap-3 text-sm text-muted-foreground">
                          <Badge variant="secondary">{service.type}</Badge>
                          <span>By {service.submittedBy}</span>
                          <span>{service.date}</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => handleApprove(service.id, service.name)}
                          data-testid={`button-approve-${service.id}`}
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Approve
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleReject(service.id, service.name)}
                          data-testid={`button-reject-${service.id}`}
                        >
                          <XCircle className="h-4 w-4 mr-1" />
                          Reject
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="add">
            <Card>
              <CardHeader>
                <CardTitle>Add New Service</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAddService} className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="service-name">Service Name</Label>
                      <Input
                        id="service-name"
                        placeholder="e.g., City Hospital"
                        required
                        data-testid="input-service-name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="service-type">Type</Label>
                      <Select value={serviceType} onValueChange={setServiceType}>
                        <SelectTrigger id="service-type" data-testid="select-service-type">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="hospital">Hospital</SelectItem>
                          <SelectItem value="pharmacy">Pharmacy</SelectItem>
                          <SelectItem value="erickshaw">E-Rickshaw</SelectItem>
                          <SelectItem value="food">Food Delivery</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="+91 98765 43210"
                        required
                        data-testid="input-phone"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="hours">Opening Hours</Label>
                      <Input
                        id="hours"
                        placeholder="e.g., 24/7 or 9 AM - 6 PM"
                        required
                        data-testid="input-hours"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="address">Address</Label>
                    <Input
                      id="address"
                      placeholder="Full address with landmarks"
                      required
                      data-testid="input-address"
                    />
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="lat">Latitude</Label>
                      <Input
                        id="lat"
                        type="number"
                        step="any"
                        placeholder="26.7"
                        required
                        data-testid="input-lat"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lng">Longitude</Label>
                      <Input
                        id="lng"
                        type="number"
                        step="any"
                        placeholder="88.4"
                        required
                        data-testid="input-lng"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="notes">Additional Notes</Label>
                    <Textarea
                      id="notes"
                      placeholder="Any additional information about the service..."
                      rows={4}
                      data-testid="input-notes"
                    />
                  </div>
                  <div className="flex justify-end gap-3">
                    <Button type="button" variant="outline" data-testid="button-cancel">
                      Cancel
                    </Button>
                    <Button type="submit" data-testid="button-add-service">
                      Add Service
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
