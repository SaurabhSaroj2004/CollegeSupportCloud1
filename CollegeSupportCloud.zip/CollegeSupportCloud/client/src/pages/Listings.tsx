import Header from '@/components/Header';
import ServiceCard from '@/components/ServiceCard';
import FilterSidebar from '@/components/FilterSidebar';
import { Button } from '@/components/ui/button';
import { SlidersHorizontal } from 'lucide-react';
import { useState } from 'react';
import { mockServices } from '@/data/mockServices';

export default function Listings() {
  const [user] = useState({ name: 'Sanny Kumar', email: 'sanny@college.edu', role: 'user' });
  const [showFilters, setShowFilters] = useState(false);
  const [filteredServices, setFilteredServices] = useState(mockServices);

  const handleFilterChange = (filters: any) => {
    let filtered = [...mockServices];

    if (filters.subcategories && filters.subcategories.length > 0) {
      filtered = filtered.filter(s => filters.subcategories.includes(s.subcategoryId));
    }

    if (filters.verified) {
      filtered = filtered.filter(s => s.verified);
    }

    if (filters.distance && filters.distance !== 'all') {
      const maxDist = parseFloat(filters.distance);
      filtered = filtered.filter(s => {
        const dist = parseFloat(s.distance);
        return dist <= maxDist;
      });
    }

    setFilteredServices(filtered);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header user={user} />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold mb-1" data-testid="text-listings-title">All Services</h1>
            <p className="text-muted-foreground">{filteredServices.length} services found</p>
          </div>
          <Button
            variant="outline"
            className="lg:hidden"
            onClick={() => setShowFilters(!showFilters)}
            data-testid="button-toggle-filters"
          >
            <SlidersHorizontal className="h-4 w-4 mr-2" />
            Filters
          </Button>
        </div>

        <div className="flex gap-6">
          <aside className={`${showFilters ? 'block' : 'hidden'} lg:block w-full lg:w-64 flex-shrink-0`}>
            <FilterSidebar onFilterChange={handleFilterChange} onClose={() => setShowFilters(false)} />
          </aside>

          <div className="flex-1">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
              {filteredServices.map((service) => (
                <ServiceCard key={service.id} {...service} />
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
