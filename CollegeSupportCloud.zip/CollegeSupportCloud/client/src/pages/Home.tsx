import Header from '@/components/Header';
import Hero from '@/components/Hero';
import CategoryCard from '@/components/CategoryCard';
import ServiceCard from '@/components/ServiceCard';
import { useState } from 'react';
import { categories, getAllSubcategories } from '@/data/categories';
import { mockServices } from '@/data/mockServices';
import { Link } from 'wouter';

export default function Home() {
  const [user] = useState({ name: 'Sanny Kumar', email: 'sanny@college.edu', role: 'admin' });

  const allSubcategories = getAllSubcategories();
  
  const categoriesWithCount = categories.map(cat => ({
    icon: cat.icon,
    title: cat.name,
    count: mockServices.filter(s => 
      cat.subcategories.some(sub => sub.id === s.subcategoryId)
    ).length,
  }));

  const featuredServices = mockServices
    .filter(s => s.verified)
    .slice(0, 6);

  return (
    <div className="min-h-screen bg-background">
      <Header user={user} />
      <Hero />
      
      <main className="max-w-7xl mx-auto px-4 py-12">
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-2 text-center" data-testid="text-categories-title">
            Explore Services
          </h2>
          <p className="text-muted-foreground text-center mb-8">
            Find what you need near your campus
          </p>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {categoriesWithCount.map((category) => (
              <Link key={category.title} href="/listings">
                <CategoryCard {...category} />
              </Link>
            ))}
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold" data-testid="text-featured-title">
                Featured Services
              </h2>
              <p className="text-muted-foreground">
                Top-rated and verified services
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredServices.slice(0, 6).map((service) => (
              <ServiceCard key={service.id} {...service} />
            ))}
          </div>
          <div className="mt-8 text-center">
            <Link href="/listings">
              <button className="px-6 py-2 bg-primary text-primary-foreground rounded-md hover-elevate active-elevate-2" data-testid="button-view-all">
                View All Services
              </button>
            </Link>
          </div>
        </section>
      </main>

      <footer className="border-t mt-16 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>&copy; 2025 College Support. All rights reserved.</p>
          <p className="mt-2">Helping students find essential services near their campus</p>
        </div>
      </footer>
    </div>
  );
}
