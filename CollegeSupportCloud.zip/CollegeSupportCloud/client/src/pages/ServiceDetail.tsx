import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Phone, MapPin, Clock, CheckCircle, Navigation, ArrowLeft } from 'lucide-react';
import { useState } from 'react';
import { useRoute, Link } from 'wouter';
import { getServiceById } from '@/data/mockServices';
import { getSubcategoryById } from '@/data/categories';

export default function ServiceDetail() {
  const [user] = useState({ name: 'Sanny Kumar', email: 'sanny@college.edu', role: 'user' });
  const [, params] = useRoute('/service/:id');
  
  const service = params?.id ? getServiceById(params.id) : null;
  const subcategory = service ? getSubcategoryById(service.subcategoryId) : null;
  const SubcategoryIcon = subcategory?.icon;

  if (!service) {
    return (
      <div className="min-h-screen bg-background">
        <Header user={user} />
        <main className="max-w-4xl mx-auto px-4 py-8">
          <Card className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-2">Service Not Found</h2>
            <p className="text-muted-foreground mb-4">The service you're looking for doesn't exist.</p>
            <Link href="/listings">
              <Button>Back to Listings</Button>
            </Link>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header user={user} />
      
      <main className="max-w-4xl mx-auto px-4 py-8">
        <Link href="/listings">
          <Button variant="ghost" className="mb-4" data-testid="button-back">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Listings
          </Button>
        </Link>

        <div className="relative h-64 md:h-96 rounded-lg overflow-hidden mb-6">
          <img src={service.image} alt={service.name} className="w-full h-full object-cover" />
          {service.verified && (
            <div className="absolute top-4 right-4">
              <Badge className="bg-green-600 text-white gap-1 px-3 py-1.5">
                <CheckCircle className="h-4 w-4" />
                Verified Service
              </Badge>
            </div>
          )}
        </div>

        <div className="mb-6">
          <div className="flex items-start justify-between gap-4 mb-4">
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-2" data-testid="text-service-name">{service.name}</h1>
              <div className="flex items-center gap-3 flex-wrap">
                <Badge variant="secondary" className="gap-1">
                  {SubcategoryIcon && <SubcategoryIcon className="h-3 w-3" />}
                  {subcategory?.name}
                </Badge>
                <span className="text-muted-foreground" data-testid="text-distance">{service.distance}</span>
              </div>
            </div>
          </div>

          <div className="flex gap-3 mb-8">
            <Button className="flex-1 md:flex-none" size="lg" data-testid="button-call">
              <Phone className="mr-2 h-5 w-5" />
              Call Now
            </Button>
            <Button variant="default" className="flex-1 md:flex-none" size="lg" data-testid="button-directions">
              <Navigation className="mr-2 h-5 w-5" />
              Get Directions
            </Button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <Card className="p-6">
            <h3 className="font-semibold text-lg mb-4">Contact Information</h3>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <Phone className="h-5 w-5 mt-0.5 text-muted-foreground flex-shrink-0" />
                <div>
                  <p className="text-sm text-muted-foreground">Phone</p>
                  <a href={`tel:${service.phone}`} className="text-primary hover:underline" data-testid="link-phone">
                    {service.phone}
                  </a>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 mt-0.5 text-muted-foreground flex-shrink-0" />
                <div>
                  <p className="text-sm text-muted-foreground">Address</p>
                  <p data-testid="text-address">{service.address}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 mt-0.5 text-muted-foreground flex-shrink-0" />
                <div>
                  <p className="text-sm text-muted-foreground">Opening Hours</p>
                  <p className="text-green-600 font-medium" data-testid="text-hours">{service.openingHours}</p>
                </div>
              </div>
            </div>
          </Card>

          {service.description && (
            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">About This Service</h3>
              <p className="text-muted-foreground leading-relaxed" data-testid="text-description">
                {service.description}
              </p>
            </Card>
          )}
        </div>

      </main>
    </div>
  );
}
