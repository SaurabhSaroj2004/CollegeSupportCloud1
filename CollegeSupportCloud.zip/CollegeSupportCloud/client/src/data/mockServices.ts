import hospitalImage from '@assets/generated_images/Hospital_service_placeholder_7e10c9c0.png';
import pharmacyImage from '@assets/generated_images/Pharmacy_service_placeholder_39df11b7.png';
import rickshawImage from '@assets/generated_images/E-rickshaw_service_placeholder_3c60da22.png';
import foodImage from '@assets/generated_images/Food_delivery_placeholder_c7214192.png';

export interface Service {
  id: string;
  name: string;
  subcategoryId: string;
  phone: string;
  address: string;
  openingHours: string;
  verified: boolean;
  distance: string;
  image: string;
  description?: string;
}

export const mockServices: Service[] = [
  // Food & Daily Needs
  {
    id: '1',
    name: 'Fresh Bakes Bakery',
    subcategoryId: 'bakery',
    phone: '+91 98765 43201',
    address: '12 College Street, Near Campus Gate',
    openingHours: '6 AM - 9 PM',
    verified: true,
    distance: '0.3 km',
    image: foodImage,
    description: 'Fresh bread, pastries, and cakes daily',
  },
  {
    id: '2',
    name: 'Campus Kirana Store',
    subcategoryId: 'grocery',
    phone: '+91 98765 43202',
    address: '45 University Avenue',
    openingHours: '7 AM - 11 PM',
    verified: true,
    distance: '0.2 km',
    image: foodImage,
    description: 'All daily essentials and groceries',
  },
  {
    id: '3',
    name: 'Student Café',
    subcategoryId: 'restaurant',
    phone: '+91 98765 43203',
    address: '78 Food Court, College Campus',
    openingHours: '8 AM - 10 PM',
    verified: true,
    distance: '0.1 km',
    image: foodImage,
    description: 'Affordable meals and snacks for students',
  },
  {
    id: '4',
    name: 'Quick Bites Restaurant',
    subcategoryId: 'restaurant',
    phone: '+91 98765 43204',
    address: '23 Market Road',
    openingHours: '10 AM - 11 PM',
    verified: true,
    distance: '0.5 km',
    image: foodImage,
    description: 'Fast food and local cuisine',
  },

  // Health & Safety
  {
    id: '5',
    name: 'City General Hospital',
    subcategoryId: 'hospital',
    phone: '+91 98765 43210',
    address: '123 College Road, Near Main Gate',
    openingHours: '24/7',
    verified: true,
    distance: '0.5 km',
    image: hospitalImage,
    description: 'Full service hospital with emergency care',
  },
  {
    id: '6',
    name: 'Campus Health Clinic',
    subcategoryId: 'clinic',
    phone: '+91 98765 43211',
    address: 'Inside College Campus, Medical Block',
    openingHours: '8 AM - 8 PM',
    verified: true,
    distance: '0.1 km',
    image: hospitalImage,
    description: 'General medical consultation and first aid',
  },
  {
    id: '7',
    name: 'MedPlus Pharmacy',
    subcategoryId: 'pharmacy',
    phone: '+91 98765 43212',
    address: '45 University Avenue, Campus Area',
    openingHours: '8 AM - 10 PM',
    verified: true,
    distance: '0.3 km',
    image: pharmacyImage,
    description: 'Medicines and healthcare products',
  },
  {
    id: '8',
    name: 'Apollo Pharmacy',
    subcategoryId: 'pharmacy',
    phone: '+91 98765 43213',
    address: '12 Health Plaza',
    openingHours: '7 AM - 11 PM',
    verified: false,
    distance: '0.7 km',
    image: pharmacyImage,
    description: '24/7 pharmacy services',
  },
  {
    id: '9',
    name: 'Emergency Ambulance Service',
    subcategoryId: 'emergency',
    phone: '108',
    address: 'City General Hospital',
    openingHours: '24/7',
    verified: true,
    distance: '0.5 km',
    image: hospitalImage,
    description: 'Emergency ambulance services',
  },

  // Academic & Study Needs
  {
    id: '10',
    name: 'Student Stationery Hub',
    subcategoryId: 'stationery',
    phone: '+91 98765 43220',
    address: '34 College Market',
    openingHours: '8 AM - 9 PM',
    verified: true,
    distance: '0.2 km',
    image: foodImage,
    description: 'Books, notebooks, pens, and all study materials',
  },
  {
    id: '11',
    name: 'Quick Copy Center',
    subcategoryId: 'photocopy',
    phone: '+91 98765 43221',
    address: '56 Library Road',
    openingHours: '7 AM - 10 PM',
    verified: true,
    distance: '0.1 km',
    image: foodImage,
    description: 'Photocopy, printing, and binding services',
  },
  {
    id: '12',
    name: 'Campus Xerox Shop',
    subcategoryId: 'photocopy',
    phone: '+91 98765 43222',
    address: 'Near College Gate',
    openingHours: '8 AM - 8 PM',
    verified: true,
    distance: '0.1 km',
    image: foodImage,
    description: 'Fast and affordable photocopying',
  },

  // Transport & Travel
  {
    id: '13',
    name: 'Main Bus Stop',
    subcategoryId: 'bus-stop',
    phone: '+91 98765 43230',
    address: 'College Main Gate',
    openingHours: '5 AM - 11 PM',
    verified: true,
    distance: '0.1 km',
    image: rickshawImage,
    description: 'City bus services to all major areas',
  },
  {
    id: '14',
    name: 'Central Railway Station',
    subcategoryId: 'railway',
    phone: '139',
    address: '2 km from College Campus',
    openingHours: '24/7',
    verified: true,
    distance: '2.0 km',
    image: rickshawImage,
    description: 'Main railway station with all major connections',
  },

  // Banking & Finance
  {
    id: '15',
    name: 'SBI ATM',
    subcategoryId: 'atm',
    phone: '+91 98765 43240',
    address: 'College Campus, Near Canteen',
    openingHours: '24/7',
    verified: true,
    distance: '0.1 km',
    image: foodImage,
    description: 'State Bank of India ATM',
  },
  {
    id: '16',
    name: 'HDFC ATM',
    subcategoryId: 'atm',
    phone: '+91 98765 43241',
    address: '45 Market Road',
    openingHours: '24/7',
    verified: true,
    distance: '0.3 km',
    image: foodImage,
    description: 'HDFC Bank ATM with cash deposit',
  },
  {
    id: '17',
    name: 'State Bank of India',
    subcategoryId: 'bank',
    phone: '+91 98765 43242',
    address: '12 Bank Street',
    openingHours: '10 AM - 4 PM (Mon-Fri)',
    verified: true,
    distance: '0.4 km',
    image: foodImage,
    description: 'Full banking services',
  },

  // Accommodation & Daily Living
  {
    id: '18',
    name: 'College PG for Boys',
    subcategoryId: 'hostel',
    phone: '+91 98765 43250',
    address: '23 Hostel Street',
    openingHours: 'Contact for visits',
    verified: true,
    distance: '0.3 km',
    image: foodImage,
    description: 'Clean and affordable PG accommodation',
  },
  {
    id: '19',
    name: 'Student Hostel for Girls',
    subcategoryId: 'hostel',
    phone: '+91 98765 43251',
    address: '45 Girls Hostel Road',
    openingHours: 'Contact for visits',
    verified: true,
    distance: '0.5 km',
    image: foodImage,
    description: 'Safe and secure hostel with all amenities',
  },
  {
    id: '20',
    name: 'Express Laundry',
    subcategoryId: 'laundry',
    phone: '+91 98765 43252',
    address: '78 Service Lane',
    openingHours: '8 AM - 8 PM',
    verified: true,
    distance: '0.2 km',
    image: foodImage,
    description: 'Washing, ironing, and dry cleaning services',
  },

  // Leisure & Fitness
  {
    id: '21',
    name: 'Fitness First Gym',
    subcategoryId: 'gym',
    phone: '+91 98765 43260',
    address: '12 Fitness Plaza',
    openingHours: '6 AM - 10 PM',
    verified: true,
    distance: '0.4 km',
    image: foodImage,
    description: 'Modern gym with all equipment and trainers',
  },
  {
    id: '22',
    name: 'College Sports Ground',
    subcategoryId: 'sports',
    phone: '+91 98765 43261',
    address: 'College Campus, Behind Main Building',
    openingHours: '6 AM - 8 PM',
    verified: true,
    distance: '0.2 km',
    image: foodImage,
    description: 'Cricket, football, basketball facilities',
  },
  {
    id: '23',
    name: 'City Cinema Hall',
    subcategoryId: 'movie',
    phone: '+91 98765 43262',
    address: '45 Entertainment Complex',
    openingHours: '10 AM - 11 PM',
    verified: true,
    distance: '0.8 km',
    image: foodImage,
    description: 'Latest movies with student discounts',
  },
];

export const getServicesBySubcategory = (subcategoryId: string): Service[] => {
  return mockServices.filter(service => service.subcategoryId === subcategoryId);
};

export const getServiceById = (id: string): Service | undefined => {
  return mockServices.find(service => service.id === id);
};
