import {
  Utensils,
  ShoppingBag,
  Coffee,
  Hospital,
  Stethoscope,
  Pill,
  Ambulance,
  PenTool,
  Printer,
  Bus,
  Train,
  Banknote,
  Building2,
  Home,
  WashingMachine,
  Dumbbell,
  Trophy,
  Film,
  type LucideIcon,
} from 'lucide-react';

export interface Category {
  id: string;
  name: string;
  icon: LucideIcon;
  subcategories: Subcategory[];
}

export interface Subcategory {
  id: string;
  name: string;
  icon: LucideIcon;
  categoryId: string;
}

export const categories: Category[] = [
  {
    id: 'food-daily-needs',
    name: 'Food & Daily Needs',
    icon: Utensils,
    subcategories: [
      { id: 'bakery', name: 'Bakery', icon: Coffee, categoryId: 'food-daily-needs' },
      { id: 'grocery', name: 'Grocery/Kirana Store', icon: ShoppingBag, categoryId: 'food-daily-needs' },
      { id: 'restaurant', name: 'Restaurants / Cafés', icon: Utensils, categoryId: 'food-daily-needs' },
    ],
  },
  {
    id: 'health-safety',
    name: 'Health & Safety',
    icon: Hospital,
    subcategories: [
      { id: 'hospital', name: 'Hospital', icon: Hospital, categoryId: 'health-safety' },
      { id: 'clinic', name: 'Clinic', icon: Stethoscope, categoryId: 'health-safety' },
      { id: 'pharmacy', name: 'Pharmacy/Medical Store', icon: Pill, categoryId: 'health-safety' },
      { id: 'emergency', name: 'Emergency Services', icon: Ambulance, categoryId: 'health-safety' },
    ],
  },
  {
    id: 'academic-study',
    name: 'Academic & Study Needs',
    icon: PenTool,
    subcategories: [
      { id: 'stationery', name: 'Stationery Shop', icon: PenTool, categoryId: 'academic-study' },
      { id: 'photocopy', name: 'Photocopy/Xerox Shop', icon: Printer, categoryId: 'academic-study' },
    ],
  },
  {
    id: 'transport-travel',
    name: 'Transport & Travel',
    icon: Bus,
    subcategories: [
      { id: 'bus-stop', name: 'Bus Stop', icon: Bus, categoryId: 'transport-travel' },
      { id: 'railway', name: 'Railway Station', icon: Train, categoryId: 'transport-travel' },
    ],
  },
  {
    id: 'banking-finance',
    name: 'Banking & Finance',
    icon: Banknote,
    subcategories: [
      { id: 'atm', name: 'ATM', icon: Banknote, categoryId: 'banking-finance' },
      { id: 'bank', name: 'Bank Branch', icon: Building2, categoryId: 'banking-finance' },
    ],
  },
  {
    id: 'accommodation-living',
    name: 'Accommodation & Daily Living',
    icon: Home,
    subcategories: [
      { id: 'hostel', name: 'Hostels/PG', icon: Home, categoryId: 'accommodation-living' },
      { id: 'laundry', name: 'Laundry/Ironing Shop', icon: WashingMachine, categoryId: 'accommodation-living' },
    ],
  },
  {
    id: 'leisure-fitness',
    name: 'Leisure & Fitness',
    icon: Dumbbell,
    subcategories: [
      { id: 'gym', name: 'Gym', icon: Dumbbell, categoryId: 'leisure-fitness' },
      { id: 'sports', name: 'Sports Ground', icon: Trophy, categoryId: 'leisure-fitness' },
      { id: 'movie', name: 'Movie Theatre', icon: Film, categoryId: 'leisure-fitness' },
    ],
  },
];

export const getAllSubcategories = (): Subcategory[] => {
  return categories.flatMap(cat => cat.subcategories);
};

export const getSubcategoryById = (id: string): Subcategory | undefined => {
  return getAllSubcategories().find(sub => sub.id === id);
};

export const getCategoryById = (id: string): Category | undefined => {
  return categories.find(cat => cat.id === id);
};
