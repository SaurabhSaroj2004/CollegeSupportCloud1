import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Phone, MapPin, Clock, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getSubcategoryById } from '@/data/categories';
import { useLocation } from 'wouter';

interface ServiceCardProps {
  id: string;
  name: string;
  subcategoryId: string;
  phone: string;
  address: string;
  openingHours?: string;
  verified?: boolean;
  distance?: string;
  image?: string;
  onClick?: () => void;
}

export default function ServiceCard({
  id,
  name,
  subcategoryId,
  phone,
  address,
  openingHours,
  verified,
  distance,
  image,
  onClick,
}: ServiceCardProps) {
  const subcategory = getSubcategoryById(subcategoryId);
  const SubcategoryIcon = subcategory?.icon;
  const [, setLocation] = useLocation();

  const handleCardClick = () => {
    onClick?.();
    console.log(`Service clicked: ${name}`);
    setLocation(`/service/${id}`);
  };

  return (
    <Card
      className="overflow-hidden hover-elevate active-elevate-2 cursor-pointer transition-all"
      onClick={handleCardClick}
      data-testid={`card-service-${id}`}
    >
        {image && (
          <div className="relative h-48 bg-muted overflow-hidden">
            <img src={image} alt={name} className="w-full h-full object-cover" />
            {verified && (
              <div className="absolute top-3 right-3">
                <Badge className="bg-green-600 text-white gap-1">
                  <CheckCircle className="h-3 w-3" />
                  Verified
                </Badge>
              </div>
            )}
          </div>
        )}
        <div className="p-4">
          <div className="flex items-start justify-between gap-2 mb-3">
            <div className="flex-1">
              <h3 className="font-semibold text-lg mb-1" data-testid={`text-service-name-${id}`}>{name}</h3>
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant="secondary" className="gap-1" data-testid={`badge-type-${id}`}>
                  {SubcategoryIcon && <SubcategoryIcon className="h-3 w-3" />}
                  {subcategory?.name}
                </Badge>
                {distance && (
                  <span className="text-xs text-muted-foreground" data-testid={`text-distance-${id}`}>
                    {distance}
                  </span>
                )}
              </div>
            </div>
          </div>

        <div className="space-y-2 text-sm">
          <div className="flex items-start gap-2 text-muted-foreground">
            <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
            <span data-testid={`text-address-${id}`}>{address}</span>
          </div>
          {openingHours && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="h-4 w-4 flex-shrink-0" />
              <span data-testid={`text-hours-${id}`}>{openingHours}</span>
            </div>
          )}
          <div className="flex items-center gap-2">
            <Phone className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
            <span className="text-sm" data-testid={`text-phone-${id}`}>
              {phone}
            </span>
          </div>
        </div>

        <div className="mt-4 flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={(e) => { e.stopPropagation(); console.log(`Calling ${name}`); }}
            data-testid={`button-call-${id}`}
          >
            <Phone className="h-4 w-4 mr-1" />
            Call
          </Button>
          <Button
            variant="default"
            size="sm"
            className="flex-1"
            onClick={(e) => { e.stopPropagation(); console.log(`Directions to ${name}`); }}
            data-testid={`button-directions-${id}`}
          >
            <MapPin className="h-4 w-4 mr-1" />
            Directions
          </Button>
        </div>
      </div>
    </Card>
  );
}
