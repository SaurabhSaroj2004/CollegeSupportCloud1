import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { X, ChevronDown } from 'lucide-react';
import { useState } from 'react';
import { categories } from '@/data/categories';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';

interface FilterSidebarProps {
  onFilterChange?: (filters: Filters) => void;
  onClose?: () => void;
}

interface Filters {
  subcategories: string[];
  verified: boolean;
  distance: string;
  openNow: boolean;
}

export default function FilterSidebar({ onFilterChange, onClose }: FilterSidebarProps) {
  const [filters, setFilters] = useState<Filters>({
    subcategories: [],
    verified: false,
    distance: 'all',
    openNow: false,
  });
  const [expandedCategories, setExpandedCategories] = useState<string[]>([]);

  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev =>
      prev.includes(categoryId)
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const handleSubcategoryChange = (subcategoryId: string, checked: boolean) => {
    const newSubcategories = checked
      ? [...filters.subcategories, subcategoryId]
      : filters.subcategories.filter(c => c !== subcategoryId);
    
    const newFilters = { ...filters, subcategories: newSubcategories };
    setFilters(newFilters);
    onFilterChange?.(newFilters);
    console.log('Subcategories updated:', newSubcategories);
  };

  const handleVerifiedChange = (checked: boolean) => {
    const newFilters = { ...filters, verified: checked };
    setFilters(newFilters);
    onFilterChange?.(newFilters);
    console.log('Verified filter:', checked);
  };

  const handleDistanceChange = (value: string) => {
    const newFilters = { ...filters, distance: value };
    setFilters(newFilters);
    onFilterChange?.(newFilters);
    console.log('Distance filter:', value);
  };

  const handleOpenNowChange = (checked: boolean) => {
    const newFilters = { ...filters, openNow: checked };
    setFilters(newFilters);
    onFilterChange?.(newFilters);
    console.log('Open now filter:', checked);
  };

  const clearFilters = () => {
    const newFilters: Filters = {
      subcategories: [],
      verified: false,
      distance: 'all',
      openNow: false,
    };
    setFilters(newFilters);
    setExpandedCategories([]);
    onFilterChange?.(newFilters);
    console.log('Filters cleared');
  };

  return (
    <Card className="p-4 h-fit">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-lg" data-testid="text-filters-title">Filters</h3>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFilters}
            data-testid="button-clear-filters"
          >
            Clear
          </Button>
          {onClose && (
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden h-8 w-8"
              onClick={() => { onClose(); console.log('Filters closed'); }}
              data-testid="button-close-filters"
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>

      <Separator className="mb-4" />

      <div className="space-y-6">
        <div>
          <Label className="text-sm font-medium mb-3 block">Categories</Label>
          <div className="space-y-2">
            {categories.map((category) => {
              const CategoryIcon = category.icon;
              const isExpanded = expandedCategories.includes(category.id);
              
              return (
                <Collapsible
                  key={category.id}
                  open={isExpanded}
                  onOpenChange={() => toggleCategory(category.id)}
                >
                  <CollapsibleTrigger className="flex items-center justify-between w-full p-2 hover-elevate rounded-md transition-all">
                    <div className="flex items-center gap-2">
                      <CategoryIcon className="h-4 w-4 text-primary" />
                      <span className="text-sm font-medium">{category.name}</span>
                    </div>
                    <ChevronDown className={`h-4 w-4 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                  </CollapsibleTrigger>
                  <CollapsibleContent className="ml-6 mt-2 space-y-2">
                    {category.subcategories.map((subcategory) => (
                      <div key={subcategory.id} className="flex items-center gap-2">
                        <Checkbox
                          id={`subcategory-${subcategory.id}`}
                          checked={filters.subcategories.includes(subcategory.id)}
                          onCheckedChange={(checked) => handleSubcategoryChange(subcategory.id, checked as boolean)}
                          data-testid={`checkbox-subcategory-${subcategory.id}`}
                        />
                        <Label
                          htmlFor={`subcategory-${subcategory.id}`}
                          className="text-sm font-normal cursor-pointer"
                        >
                          {subcategory.name}
                        </Label>
                      </div>
                    ))}
                  </CollapsibleContent>
                </Collapsible>
              );
            })}
          </div>
        </div>

        <Separator />

        <div>
          <Label className="text-sm font-medium mb-3 block">Distance</Label>
          <RadioGroup value={filters.distance} onValueChange={handleDistanceChange}>
            {[
              { value: 'all', label: 'All' },
              { value: '1', label: 'Within 1 km' },
              { value: '3', label: 'Within 3 km' },
              { value: '5', label: 'Within 5 km' },
            ].map(option => (
              <div key={option.value} className="flex items-center gap-2">
                <RadioGroupItem
                  value={option.value}
                  id={`distance-${option.value}`}
                  data-testid={`radio-distance-${option.value}`}
                />
                <Label
                  htmlFor={`distance-${option.value}`}
                  className="text-sm font-normal cursor-pointer"
                >
                  {option.label}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </div>

        <Separator />

        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Checkbox
              id="verified"
              checked={filters.verified}
              onCheckedChange={handleVerifiedChange}
              data-testid="checkbox-verified"
            />
            <Label htmlFor="verified" className="text-sm font-normal cursor-pointer">
              Verified only
            </Label>
          </div>
          <div className="flex items-center gap-2">
            <Checkbox
              id="open-now"
              checked={filters.openNow}
              onCheckedChange={handleOpenNowChange}
              data-testid="checkbox-open-now"
            />
            <Label htmlFor="open-now" className="text-sm font-normal cursor-pointer">
              Open now
            </Label>
          </div>
        </div>
      </div>
    </Card>
  );
}
