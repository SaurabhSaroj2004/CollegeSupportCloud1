import CategoryCard from '../CategoryCard';
import { Hospital } from 'lucide-react';

export default function CategoryCardExample() {
  return <CategoryCard icon={Hospital} title="Hospital" count={125} />;
}
