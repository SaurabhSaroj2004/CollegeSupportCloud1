import Header from '../Header';

export default function HeaderExample() {
  return (
    <Header 
      user={{ name: 'Sanny Kumar', email: 'sanny@college.edu', role: 'admin' }}
    />
  );
}
