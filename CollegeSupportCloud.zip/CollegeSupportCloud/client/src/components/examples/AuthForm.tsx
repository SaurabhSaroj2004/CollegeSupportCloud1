import AuthForm from '../AuthForm';

export default function AuthFormExample() {
  return <AuthForm mode="login" />;
}
