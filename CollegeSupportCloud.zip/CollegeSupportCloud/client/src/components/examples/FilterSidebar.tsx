import FilterSidebar from '../FilterSidebar';

export default function FilterSidebarExample() {
  return <FilterSidebar />;
}
