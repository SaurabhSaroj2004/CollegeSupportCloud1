import ServiceCard from '../ServiceCard';
import hospitalImage from '@assets/generated_images/Hospital_service_placeholder_7e10c9c0.png';

export default function ServiceCardExample() {
  return (
    <ServiceCard
      id="1"
      name="City General Hospital"
      type="hospital"
      phone="+91 98765 43210"
      address="123 College Road, Near Main Gate"
      openingHours="24/7"
      verified={true}
      distance="0.5 km"
      image={hospitalImage}
    />
  );
}
