import { Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useState } from 'react';
import heroImage from '@assets/generated_images/College_campus_hero_image_15d9a68f.png';

interface HeroProps {
  onSearch?: (query: string, category: string) => void;
}

export default function Hero({ onSearch }: HeroProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [category, setCategory] = useState('all');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch?.(searchQuery, category);
    console.log('Hero search:', searchQuery, category);
  };

  return (
    <div className="relative h-[60vh] min-h-[500px] flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/70" />
      
      <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4" data-testid="text-hero-title">
          Find Support Services Near Your Campus
        </h1>
        <p className="text-lg md:text-xl text-white/90 mb-8" data-testid="text-hero-subtitle">
          Access verified hospitals, pharmacies, transportation, and food delivery services
        </p>
        
        <form onSubmit={handleSearch} className="max-w-3xl mx-auto">
          <div className="flex flex-col md:flex-row gap-3 bg-white/95 backdrop-blur-md p-3 rounded-lg shadow-xl">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search for services..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12 border-0 bg-transparent text-base"
                data-testid="input-hero-search"
              />
            </div>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="w-full md:w-48 h-12 border-0 bg-transparent" data-testid="select-hero-category">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Services</SelectItem>
                <SelectItem value="hospital">Hospital</SelectItem>
                <SelectItem value="pharmacy">Pharmacy</SelectItem>
                <SelectItem value="erickshaw">E-Rickshaw</SelectItem>
                <SelectItem value="food">Food Delivery</SelectItem>
              </SelectContent>
            </Select>
            <Button type="submit" size="lg" className="h-12 px-8" data-testid="button-hero-search">
              Search
            </Button>
          </div>
        </form>

        <div className="mt-6 flex items-center justify-center gap-6 text-white/90 text-sm">
          <div data-testid="text-stat-services">
            <span className="font-bold text-2xl text-white">500+</span>
            <p>Verified Services</p>
          </div>
          <div className="h-8 w-px bg-white/30" />
          <div data-testid="text-stat-colleges">
            <span className="font-bold text-2xl text-white">50+</span>
            <p>Colleges Covered</p>
          </div>
          <div className="h-8 w-px bg-white/30" />
          <div data-testid="text-stat-users">
            <span className="font-bold text-2xl text-white">10K+</span>
            <p>Students Helped</p>
          </div>
        </div>
      </div>
    </div>
  );
}
